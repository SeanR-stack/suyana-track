#!/usr/bin/env python3
"""
Soybean yield model for the Suyana climate-loan demo.

Data: SustainBench Crop Yield dataset v1.0 (soybeans_updated.zip), a processed
version of the dataset from Wang et al. 2018 (Deep Transfer Learning for Crop
Yield Prediction with Remote Sensing Data, ACM COMPASS,
https://doi.org/10.1145/3209811.3212707).
Retrieval (no account needed):
    pip install gdown
    gdown --folder 'https://drive.google.com/drive/folders/1hsp2PlXAgcQ0pbx_vvPKHZcj_Am3rWx4'
    unzip -o crop_yield/soybeans_updated.zip -d extracted
sha256 (verified 2026-11-10):
    soybeans_updated.zip = ff66f83a91a16b302c731c7efa4020ecf323d96beca2f1f9196a643efdb8ea4a
Docs: https://sustainlab-group.github.io/sustainbench/docs/datasets/sdg2/crop_yield.html
License: SustainBench states raw data is CC-BY-SA 4.0; code MIT.
Inputs are MODIS-derived seasonal histograms; labels are government
region-level soybean yield statistics, 2005-2016.

Running this single script reproduces everything:
    CROP_DATA=extracted/soybeans python3 train_eval.py
outputs (next to this script): metrics.json, test_year_predictions.csv,
model_ridge_{brazil,argentina,usa}.joblib

What is measured: END-OF-SEASON retrospective regional yield estimation
(features span the full harvest season - nothing here is advance forecasting).
  - New-year holdout: train 2005-2013, estimate 2014-2016.
  - New-region holdout: 25% of counties fully held out (seed 42); both sides
    span 2005-2016 (same years' climate on both sides).
Baselines reported beside every model: global train mean, and each region's
own training-history mean (fallback: global mean for history-less regions).
Models: ridge on 326 aggregated features; gradient boosting on NDVI curve.
Exploratory: yield-anomaly estimation and bad-season detection.
Nothing here predicts loan default or parcel-level stress.
"""
import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

DATA_DIR = os.environ.get("CROP_DATA", "extracted/soybeans")
OUT_DIR = os.path.dirname(os.path.abspath(__file__))
TRAIN_END_YEAR = 2013  # test = 2014-2016 (held-out later years)
SPATIAL_HOLDOUT_FRAC = 0.25
SEED = 42


def load_country(country):
    hists, ndvis, ys, years, keys = [], [], [], [], []
    for fname in ["train", "dev", "test"]:
        h = np.load(f"{DATA_DIR}/{country}/{fname}_hists.npz")["data"].astype(np.float32)
        # aggregate each band's histogram over the season's timesteps -> (N, 32*9)
        hists.append(h.mean(axis=2).reshape(len(h), -1))
        del h
        ndvis.append(np.load(f"{DATA_DIR}/{country}/{fname}_ndvi.npz")["data"].astype(np.float32))
        ys.append(np.load(f"{DATA_DIR}/{country}/{fname}_yields.npz")["data"].astype(np.float64))
        years.append(np.load(f"{DATA_DIR}/{country}/{fname}_years.npz")["data"].astype(int))
        keys.append(np.load(f"{DATA_DIR}/{country}/{fname}_keys.npz")["data"])
    X_hist = np.concatenate(hists)
    ndvi = np.concatenate(ndvis)
    y = np.concatenate(ys)
    yr = np.concatenate(years)
    keys = np.concatenate(keys)
    county = np.array([k.rsplit("_", 1)[0] for k in keys])
    return X_hist, ndvi, y, yr, county


def ndvi_summary(ndvi):
    filled = np.where(np.isnan(ndvi), np.expand_dims(np.nanmean(ndvi, axis=1), 1), ndvi)
    return np.column_stack([filled.mean(1), filled.std(1), filled.min(1), filled.max(1),
                            filled.argmax(1).astype(np.float32), filled.sum(1)])


def metrics(y_true, y_pred):
    return {
        "rmse_t_per_ha": round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 4),
        "mae_t_per_ha": round(float(mean_absolute_error(y_true, y_pred)), 4),
        "r2": round(float(r2_score(y_true, y_pred)), 4),
    }


def build_features(X_hist, ndvi):
    return np.hstack([ndvi, ndvi_summary(ndvi), X_hist])


def make_ridge():
    return make_pipeline(SimpleImputer(strategy="mean"), StandardScaler(),
                         RidgeCV(alphas=np.logspace(-2, 4, 25)))


def evaluate_split(X_hist, ndvi, y, county, tr, te):
    ytr, yte = y[tr], y[te]
    out = {"n_train": int(tr.sum()), "n_test": int(te.sum())}

    out["baseline_global_mean"] = metrics(yte, np.full_like(yte, ytr.mean()))
    cmean = {c: ytr[county[tr] == c].mean() for c in set(county[tr])}
    pred = np.array([cmean.get(c, ytr.mean()) for c in county[te]])
    out["baseline_county_mean"] = metrics(yte, pred)

    Xall = build_features(X_hist, ndvi)
    Xtr, Xte = Xall[tr], Xall[te]

    ridge = make_ridge()
    ridge.fit(Xtr, ytr)
    out["ridge_ndvi_histagg"] = metrics(yte, ridge.predict(Xte))

    ndvi_only_tr = np.nan_to_num(Xtr[:, :38], nan=np.nanmean(Xtr[:, :38]))
    ndvi_only_te = np.nan_to_num(Xte[:, :38], nan=np.nanmean(Xtr[:, :38]))
    gbr = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05,
                                        max_depth=6, random_state=SEED)
    gbr.fit(ndvi_only_tr, ytr)
    out["gbr_ndvi"] = metrics(yte, gbr.predict(ndvi_only_te))

    for k, v in out.items():
        if isinstance(v, dict):
            print(f"  {k:28s} rmse={v['rmse_t_per_ha']:.3f} mae={v['mae_t_per_ha']:.3f} r2={v['r2']:.3f}")
    return out


def run_country(country, results):
    X_hist, ndvi, y, yr, county = load_country(country)
    entry = {"n_samples": int(len(y)), "n_counties": int(len(set(county))),
             "years": [int(yr.min()), int(yr.max())],
             "yield_mean_t_per_ha": round(float(y.mean()), 3),
             "yield_std_t_per_ha": round(float(y.std()), 3)}

    tr, te = yr <= TRAIN_END_YEAR, yr > TRAIN_END_YEAR
    print(f"\n=== {country}: new-year holdout (train <= {TRAIN_END_YEAR}, test 2014-2016) "
          f"n_train={tr.sum()} n_test={te.sum()} ===")
    entry["new_year_holdout"] = evaluate_split(X_hist, ndvi, y, county, tr, te)

    rng = np.random.RandomState(SEED)
    counties = np.array(sorted(set(county)))
    holdout = set(rng.choice(counties, size=max(1, int(len(counties) * SPATIAL_HOLDOUT_FRAC)), replace=False))
    is_ho = np.array([c in holdout for c in county])
    print(f"=== {country}: new-region holdout ({len(holdout)}/{len(counties)} counties held out, "
          f"both sides span 2005-2016) n_train={(~is_ho).sum()} n_test={is_ho.sum()} ===")
    entry["new_region_holdout"] = evaluate_split(X_hist, ndvi, y, county, ~is_ho, is_ho)

    results[country] = entry
    return X_hist, ndvi, y, yr, county


def run_transfer(results):
    """Train on US (large), estimate AR and BR held-out later years. Honest check
    of whether a big-data model transfers without local training data."""
    X_us, ndvi_us, y_us, yr_us, _ = load_country("usa")
    tr = yr_us <= TRAIN_END_YEAR
    Xus = build_features(X_us, ndvi_us)
    ridge = make_ridge()
    ridge.fit(Xus[tr], y_us[tr])

    transfer = {}
    for country in ["argentina", "brazil"]:
        X_c, ndvi_c, y_c, yr_c, county_c = load_country(country)
        te = yr_c > TRAIN_END_YEAR
        Xc = build_features(X_c, ndvi_c)
        pred = ridge.predict(Xc[te])
        ytr_c = y_c[yr_c <= TRAIN_END_YEAR]
        cmean = {c: ytr_c[county_c[yr_c <= TRAIN_END_YEAR] == c].mean()
                 for c in set(county_c[yr_c <= TRAIN_END_YEAR])}
        base = np.array([cmean.get(c, ytr_c.mean()) for c in county_c[te]])
        transfer[country] = {
            "us_trained_ridge": metrics(y_c[te], pred),
            "local_county_mean_baseline": metrics(y_c[te], base),
        }
        print(f"=== transfer US -> {country} (test 2014-2016): "
              f"model rmse={transfer[country]['us_trained_ridge']['rmse_t_per_ha']:.3f} "
              f"vs county-mean rmse={transfer[country]['local_county_mean_baseline']['rmse_t_per_ha']:.3f}")
        del X_c, ndvi_c, Xc
    results["transfer_us_to_latam"] = transfer


def run_anomaly_task(results):
    """Exploratory stress-framed task: estimate yield ANOMALY vs the region's own
    2005-2013 mean, on held-out years 2014-2016, plus binary detection of a
    'bad season' (yield > 0.5 training-std below the region's training mean).
    Added after seeing new-year results; report as exploratory."""
    from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
    out = {}
    for country in ["brazil", "argentina", "usa"]:
        X_hist, ndvi, y, yr, county = load_country(country)
        tr, te = yr <= TRAIN_END_YEAR, yr > TRAIN_END_YEAR
        ytr = y[tr]
        cstats = {}
        for c in set(county[tr]):
            vals = ytr[county[tr] == c]
            cstats[c] = (vals.mean(), max(vals.std(), 1e-6))
        gmean, gstd = ytr.mean(), ytr.std()
        mu = np.array([cstats.get(c, (gmean, gstd))[0] for c in county])
        sd = np.array([cstats.get(c, (gmean, gstd))[1] for c in county])
        dev = y - mu

        Xall = build_features(X_hist, ndvi)
        Xtr, Xte = Xall[tr], Xall[te]
        ydev_tr, ydev_te = dev[tr], dev[te]

        gbr = HistGradientBoostingRegressor(max_iter=400, learning_rate=0.05,
                                            max_depth=6, random_state=SEED)
        gbr.fit(np.nan_to_num(Xtr, nan=np.nanmean(Xtr)), ydev_tr)
        pdev = gbr.predict(np.nan_to_num(Xte, nan=np.nanmean(Xtr)))

        entry = {"n_train": int(tr.sum()), "n_test": int(te.sum())}
        entry["baseline_zero_anomaly"] = metrics(ydev_te, np.zeros_like(ydev_te))
        entry["gbr_anomaly"] = metrics(ydev_te, pdev)

        bad_true = (ydev_te < -0.5 * sd[te]).astype(int)
        bad_pred = (pdev < -0.5 * sd[te]).astype(int)
        if bad_true.sum() > 0 and bad_pred.sum() > 0:
            entry["bad_season_detection"] = {
                "prevalence": round(float(bad_true.mean()), 3),
                "precision": round(float(precision_score(bad_true, bad_pred)), 3),
                "recall": round(float(recall_score(bad_true, bad_pred)), 3),
                "f1": round(float(f1_score(bad_true, bad_pred)), 3),
                "roc_auc": round(float(roc_auc_score(bad_true, -pdev)), 3),
            }
        else:
            entry["bad_season_detection"] = "degenerate (no positive labels in test or predictions)"
        out[country] = entry
        print(f"=== anomaly task {country}: baseline rmse={entry['baseline_zero_anomaly']['rmse_t_per_ha']:.3f} "
              f"gbr rmse={entry['gbr_anomaly']['rmse_t_per_ha']:.3f} r2={entry['gbr_anomaly']['r2']:.3f} "
              f"detection={entry['bad_season_detection']}")
        del X_hist, ndvi, Xall
    results["yield_anomaly_task_exploratory"] = out


def export_models_and_predictions(results):
    """Refit the exact ridge new-year-holdout pipeline per country and export
    fitted models plus per-row held-out predictions. Refit is deterministic
    (RidgeCV has no randomness), so CSV metrics match metrics.json exactly."""
    rows = []
    for country in ["brazil", "argentina", "usa"]:
        X_hist, ndvi, y, yr, county = load_country(country)
        tr, te = yr <= TRAIN_END_YEAR, yr > TRAIN_END_YEAR
        Xall = build_features(X_hist, ndvi)
        ridge = make_ridge()
        ridge.fit(Xall[tr], y[tr])
        pred = ridge.predict(Xall[te])
        m = metrics(y[te], pred)
        assert m == results[country]["new_year_holdout"]["ridge_ndvi_histagg"], \
            f"{country}: export metrics {m} != metrics.json {results[country]['new_year_holdout']['ridge_ndvi_histagg']}"
        joblib.dump(ridge, os.path.join(OUT_DIR, f"model_ridge_{country}.joblib"))
        for c, yv, pv, yrr in zip(county[te], y[te], pred, yr[te]):
            rows.append({"country": country, "county": c, "year": int(yrr),
                         "actual_yield_t_ha": round(float(yv), 3),
                         "predicted_yield_t_ha": round(float(pv), 3)})
        del X_hist, ndvi, Xall
    pd.DataFrame(rows).to_csv(os.path.join(OUT_DIR, "test_year_predictions.csv"), index=False)
    print(f"wrote test_year_predictions.csv ({len(rows)} rows) and model_ridge_*.joblib")


def main():
    results = {"dataset": "SustainBench Crop Yield v1.0 (derived from Wang et al. 2018)",
               "data_license": "CC-BY-SA 4.0 per SustainBench README; code MIT",
               "downloaded": "2026-11-10",
               "sha256_soybeans_updated_zip":
                   "ff66f83a91a16b302c731c7efa4020ecf323d96beca2f1f9196a643efdb8ea4a",
               "seed": SEED,
               "task": "end-of-season retrospective regional yield estimation (full-season features)",
               "train_years": f"2005-{TRAIN_END_YEAR}", "test_years": "2014-2016"}
    for country in ["brazil", "argentina", "usa"]:
        run_country(country, results)
    run_transfer(results)
    run_anomaly_task(results)
    with open(os.path.join(OUT_DIR, "metrics.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("\nwrote metrics.json")
    export_models_and_predictions(results)


if __name__ == "__main__":
    main()
