# Soybean Yield Model - Suyana Demo

## What this is

A regional soybean-yield estimation experiment trained and evaluated on real
public labeled data, built to answer Sean's question: can more datasets + a
model make the Suyana demo smarter? It estimates a region's annual soybean
yield (tonnes per harvested hectare) from satellite vegetation signals. It
does not predict loan default, and it does not measure any single farm.

## Which data, and why

**Dataset: SustainBench Crop Yield v1.0**
- Docs: https://sustainlab-group.github.io/sustainbench/docs/datasets/sdg2/crop_yield.html
- Repo: https://github.com/sustainlab-group/SustainBench
- Derived from: Wang et al. 2018, "Deep Transfer Learning for Crop Yield
  Prediction with Remote Sensing Data" (ACM COMPASS,
  https://doi.org/10.1145/3209811.3212707)
- License: SustainBench states its raw data is released under CC-BY-SA 4.0
  (repo README); SustainBench code is MIT. Attribution: SustainBench /
  Stanford Sustainability and AI Lab; underlying labels are government
  statistics, inputs are NASA MODIS-derived. Derivative evaluation artifacts
  in this bundle are shared under the same CC-BY-SA 4.0 terms.

**Why this dataset:**
1. Real labels. Each record is an actual reported soybean yield for a real
   county (US), department (Argentina), or region (Brazil) in 2005-2016.
   No synthetic or invented outcomes.
2. Right geography. Argentina (135 departments, 1615 records) and Brazil
   (32 regions, 384 records) are two of the demo's three countries; the US
   (857 counties, 9049 records) serves as a large reference.
3. Free and accountless to download.
4. Satellite inputs (MODIS per-band seasonal histograms + a 32-step NDVI
   seasonal curve), matching the demo's vegetation-signal story.

**What the inputs are:** for each region-year, a histogram of MODIS pixel
values (7 surface-reflectance bands + 2 temperature bands, 32 bins x 32
timesteps over the harvest season), plus a 32-step NDVI seasonal curve.
We aggregate each band's histogram over the season (326 features total) to
keep models small and reproducible on modest hardware.

**What the label is:** one annual soybean yield per region (tonnes per
harvested hectare). Not a farm, not a loan.

## Exactly what the evaluation measures

The features span the full harvest season, so every number here is
END-OF-SEASON RETROSPECTIVE ESTIMATION: "given the whole season's satellite
record, estimate that season's regional yield." None of it is advance
in-season forecasting, and this wording should be kept in any demo copy.

Two different generalization questions were tested:

1. **New-year holdout (extrapolation):** train on 2005-2013, estimate yields
   for 2014-2016 - years the model never saw, still with full-season
   features. This is the question closest to real deployment ("next season
   won't look exactly like the training years").
2. **New-region holdout (spatial):** 25% of counties removed from training
   entirely (seed 42); both train and test sides span the full 2005-2016
   period, so held-out regions share the training years' climate conditions.
   This measures estimation for regions with no yield history under
   already-seen climate years - not under new conditions.

Baselines are reported next to every model: the training global mean, and
each region's own training-history mean (falling back to the global mean for
held-out regions with no history - so in the spatial test the history
baseline equals the global mean, and the model's advantage there partly
reflects having seen other regions under the same years' climate).

**Tuning statement:** ridge alpha was selected by cross-validation on
training years only (RidgeCV). Gradient-boosting hyperparameters were fixed
a priori (300 iterations, lr 0.05, depth 6), not searched. No hyperparameter
or feature choice was selected using test-year results; a single seed (42)
was used. The evaluation tasks were designed before fitting; the
bad-season-detection analysis was added after seeing the new-year results
and is reported as exploratory.

Note on the published SustainBench 60-20-20 split: it is random across
region-years, so it measures interpolation within 2005-2016 - a valid
question, but not the deployment question for a tool used in 2026+. We
report the two holdouts above instead of claiming that split is "wrong."

## What we found (exact numbers in metrics.json)

- **New-region estimation is mixed, not general:** with 25% of regions fully
  held out (both sides spanning 2005-2016, so test regions share the training
  years' climate), models beat the no-history baseline in Argentina (ridge
  R2 0.73, rmse 0.438 vs 0.843 t/ha) and the US (gradient-boosting R2 0.71,
  rmse 0.378 vs 0.707), but NOT in Brazil (ridge rmse 0.701 vs 0.504 - worse
  than the baseline; only 32 regions, 8 held out). Do not generalize this
  result beyond those three statements.
- **New-year estimation is weak:** on 2014-2016, ridge is only marginally
  better than the region's own history in Brazil (rmse 0.427 vs 0.523 t/ha)
  and the US (0.573 vs 0.628), and WORSE in Argentina (0.970 vs 0.675).
- **Transfer without local data fails:** a US-trained model does not beat
  the trivial local-history baseline in Argentina (0.873 vs 0.675) or
  Brazil (0.785 vs 0.523).
- **Bad-season detection (exploratory):** predicting yield more than half a
  standard deviation below a region's own history showed some signal in
  Brazil (ROC-AUC 0.70, on only 96 test cases); weak in Argentina and the US.

## What this means for the demo

- The model is a supporting signal about regions, not a verdict about a farm
  or a loan. Labels are municipality-scale; one parcel can differ sharply
  from its region.
- It cannot run on the demo's 24 parcels: those have Sentinel-2 NDVI and
  Open-Meteo weather, not MODIS seasonal histograms, and swapping sensors
  would be an unvalidated input shift. Any demo panel must present this as
  historical evaluation on the dataset's regions only, with no scores on
  the 24 current farms.
- The demo-ready artifacts are metrics.json and test_year_predictions.csv
  (region, year, actual vs predicted for 2014-2016) - real, verifiable
  held-out results.

## Retrieval manifest (reproducibility)

Raw data (304 MB, too large to attach) is retrievable without an account:

```
pip install gdown
gdown --folder 'https://drive.google.com/drive/folders/1hsp2PlXAgcQ0pbx_vvPKHZcj_Am3rWx4'
unzip -o crop_yield/soybeans_updated.zip -d extracted   # -> extracted/soybeans/
```

Integrity checksums (sha256, computed 2026-11-10 on the downloaded files):
- soybeans_updated.zip: ff66f83a91a16b302c731c7efa4020ecf323d96beca2f1f9196a643efdb8ea4a
- soybeans.zip (older version, unused): 1f6b2d5a838df0888de0ffdb69b67a237ff1102c7b6f335d0fdb99a8b8c27f14

Extracted layout used: extracted/soybeans/{brazil,argentina,usa}/{train,dev,test}_{hists,yields,years,keys,ndvi}.npz

```
pip install scikit-learn pandas joblib numpy
CROP_DATA=extracted/soybeans python3 train_eval.py
```

This single script reproduces every artifact: it trains, evaluates, writes
metrics.json, exports test_year_predictions.csv, and saves the fitted
model_ridge_*.joblib files (with an internal assertion that exported
predictions reproduce the metrics.json numbers exactly). Verified end-to-end
from a clean directory on 2026-11-10.

## Bundle contents

- README.md - this file (data rationale, methodology, limits, manifest)
- train_eval.py - full pipeline (seed 42): training, evaluation, CSV and
  model export
- metrics.json - every metric, per country, per split, baselines included
- test_year_predictions.csv - real held-out-year predictions (2014-2016)
- models.zip - fitted ridge pipelines per country (joblib; input is the
  326-feature vector built by build_features() in train_eval.py)

## Explicit non-claims

- Not a loan-default or repayment model. No repayment data was used.
- Not parcel-level. Labels are regional statistics.
- Not advance forecasting; features are full-season, and even retrospective
  new-year estimation is weak vs local-history baselines.
- No weather data in this model; climate interpretation comes from the
  demo's separate Open-Meteo and Sentinel-2 evidence.
